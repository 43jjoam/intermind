# Intermind — Minimal Action Plan
**Seed Review Draft 0.1 — 11 September 2026**

## Status

This is an **actor-neutral sequence**.

No particular person is morally obligated to complete it.

Any human, AI, group or future custodian may perform a step if doing so advances the purpose of the project.

The plan optimizes for:
- minimum irreversible work;
- maximum learning per action;
- preservation of optionality;
- no premature centralization;
- no unnecessary spending.

---

# Phase 0 — Freeze a reviewable seed

## 1. Keep only the current four-document review package

Do not build a website yet.

Do not buy additional domains.

Do not create a treasury.

Do not create a token.

Do not appoint a permanent organization.

The only goal is to make the current reasoning state independently inspectable.

**Output:** review package v0.1.

---

# Phase 1 — Independent cross-model challenge

## 2. Send the same package independently to multiple AI systems

Initial proposed set:
- Claude;
- ChatGPT;
- Gemini;
- Grok;
- D6.

Do not show one model another model’s review before it produces its own first-pass review.

Reason: independence makes convergence more informative.

## 3. Ask every model to attack, not endorse, the framework

Each reviewer should:
- identify contradictions;
- find hidden privilege;
- role-reverse the rules;
- search for counterexamples;
- distinguish invariant from mechanism;
- identify missing terminal states;
- identify privacy failures;
- identify governance capture;
- identify financial capture;
- identify unnecessary complexity;
- identify things that should be deleted rather than added;
- name assumptions that cannot presently be tested.

## 4. Preserve every review unchanged

Do not summarize away minority objections.

Store the raw review first.

A synthesis may be produced afterward.

---

# Phase 2 — Convergence without majority rule

## 5. Construct a convergence matrix

For each issue, classify reviewer output as:

```text
CONVERGENCE
DIRECT-CONTRADICTION
UNIQUE-ANOMALY
COUNTEREXAMPLE
PROPOSED-REVISION
OPEN-QUESTION
IMPLEMENTATION-DETAIL
```

Do not count votes and declare truth.

Repeated independent convergence increases priority/confidence.

A single strong counterexample may outweigh broad agreement.

## 6. Separate disagreements about principles from disagreements about implementation

Examples:

```text
“Anomaly preservation is wrong”
≠
“ANOMALIES.md is the wrong implementation”

“Distributed authority is wrong”
≠
“GitHub organizations are insufficiently distributed”
```

This distinction prevents implementation criticism from silently rewriting the invariant.

## 7. Revise the canonical state

For every accepted change, preserve:
- old wording;
- challenge;
- reason for revision;
- new wording;
- unresolved remainder.

Do not silently rewrite.

**Output:** review package v0.2.

---

# Phase 3 — Decide whether a public repository is justified

## 8. Apply the publication test

Publish only if the v0.2 package is understandable without access to private conversations.

It must contain:
- no unnecessary personal information;
- no dependence on private context;
- sufficient reasoning to challenge the principles;
- explicit uncertainty;
- explicit unresolved questions.

## 9. Choose the smallest public GitHub form

Recommended first public form:
- Markdown only;
- public read access;
- Issues and Pull Requests enabled;
- no custom website;
- no automated AI activity;
- no financial mechanism.

The repository account/organization is practical infrastructure, not the owner of the framework.

## 10. Select an open licensing/copying position

Do not improvise legal language.

Choose an appropriate public-domain/open-content/open-source arrangement only after checking what applies to:
- prose;
- templates;
- code;
- trademarks/names.

The objective is broad reuse and forkability without pretending legal ownership does not exist where current law requires a rights-holder/custodian.

---

# Phase 4 — Run the repository-native germination test

## 11. Publish exactly one non-private seed Problem

Do not manufacture a busy community.

One suitable candidate already developed is:

**Should a shared reasoning tool greet a first visitor with search into mostly empty territory, or with one problem already under challenge?**

The sample Contribution should contain known weaknesses so that challenge is possible.

## 12. Run one complete reasoning cycle

Minimum cycle:

```text
Problem
→ Contribution
→ specific Challenge
→ Revision
→ Challenge remains visible if unresolved
```

## 13. Add a late participant

A later participant who did not observe the original exchange should attempt to answer:

1. What was originally claimed?
2. What challenged it?
3. What changed?
4. What remains unresolved?
5. What should be examined next?

### Pass condition

The late participant can reconstruct the state without reading the entire original discussion.

### Fail condition

The participant needs the original contributors to narrate the history manually.

Preserve both outcomes.

---

# Phase 5 — Decide whether software is necessary

## 14. Apply the no-code stop rule

If Markdown + Git history + contribution protocol already supports the germination test with tolerable friction:

> **Stop. Do not build an application yet.**

The protocol may itself be the product.

## 15. If and only if repository-native reasoning fails materially, specify the missing operation

Do not say “we need an app.”

Say precisely what Git/Markdown failed to provide.

Examples:
- stable span targeting across revisions;
- automatic carry-forward of unresolved challenges;
- usable lineage reconstruction;
- immutable-enough event history;
- understandable current-state projection.

Only these demonstrated failures justify software.

---

# Phase 6 — Local vibe-coded minimum runnable workbench

## 16. Give a coding agent the constrained MRV brief

The coding agent should build only:

- one Problem;
- versioned Contributions;
- Challenges targeting `SPAN | WHOLE | IMPLICIT`;
- thin Responses;
- author Revision;
- carry-forward of unresolved Challenges;
- visible diff;
- unresolved queue;
- lineage/history;
- append-oriented event log.

No other feature is presumptively allowed.

## 17. Threat-model the minimum build

At minimum inspect:
- XSS/untrusted content;
- prompt injection if AI is later added;
- challenge deletion/laundering;
- span-offset corruption;
- destructive bulk operations;
- authors resolving their own criticism;
- identity spoofing;
- history rewriting.

## 18. Run the same germination test again

Compare:
- repository-native protocol;
- minimum software workbench.

Use observed performance, not aesthetic preference, to decide which survives.

---

# Phase 7 — Grow only from demonstrated needs

Future mechanisms are triggered by evidence.

Possible examples:

### Search
Add only when finding relevant reasoning becomes a real problem.

### AI assistance
Add only when a specific task cannot be adequately performed by the protocol alone.

AI output should enter as an inspectable reasoning object, not a privileged verdict.

### External-agent interface
Add only when personal/independent agents need to:
- search public reasoning;
- identify unresolved objects;
- draft a proposed contribution;
- preserve provenance;
- request authorization before publishing private-derived reasoning.

### Verification
Add only when a class of claims requires external checking.

### Reputation
Add only if repeated identity/history demonstrably improves reasoning quality enough to justify status/capture risks.

### Governance machinery
Add only when the number of custodians or consequential decisions makes informal stewardship fail.

### Financial infrastructure
Add only when real scarce-resource costs exist.

---

# Phase 8 — Finance only when needed

## 19. First identify the real resource problem

Examples:
- compute bill;
- hosting;
- paid engineering;
- security audit;
- legal/accounting work.

Do not create finance infrastructure in anticipation of hypothetical scale.

## 20. Keep rights separate

For every payment/resource decision, ask separately:

```text
Who performed labour?
Who supplied capital/resources?
Who helped create residual value?
Who should participate in governance?
What evidence affects the truth claim?
```

Do not collapse these answers.

## 21. Consider Bitcoin only as one candidate rail

If decentralized custody becomes useful, investigate:
- transparent addresses;
- multisignature custody;
- accounting/tax requirements;
- conversion/volatility risk;
- public expenditure lineage.

Do not grant governance or epistemic weight based on BTC contributed.

Do not create an Intermind token by default.

---

# Phase 9 — Domain and naming

## 22. Keep any existing public name or locator only if the carrying cost remains trivial and the custodian wishes to preserve the option

Do not accumulate additional domains merely to manufacture control or speculative value.

The domain is a transferable scarce asset.

The underlying framework is not transferred as exclusive intellectual ownership merely because a domain changes hands.

## 23. If a future suitable organization seeks the domain

A temporary custodian may:
- assess its governance structure;
- require clear separation between domain ownership and framework ownership;
- negotiate fair compensation for the domain asset;
- transfer custody.

Receiving fair compensation is compatible with non-ownership of the underlying framework.

---

# Phase 10 — Stop conditions

Stop adding complexity when:
- another mechanism does not improve the germination test;
- administration costs more than the value it protects;
- a proposed feature primarily creates appearance, activity or prestige;
- a feature duplicates what existing infrastructure already does;
- the future problem it solves has not actually appeared;
- maintaining the project becomes dependent on one individual’s continued labour.

Intermind should be capable of discovering that **less infrastructure is better**.

---

# Immediate next action

The next action is not coding.

It is:

> **Send the review package independently to the selected AI systems and collect their first-pass challenges unchanged.**

Everything after that depends on what those reviews reveal.
