# Intermind — Canonical Project State
**Seed Review Draft 0.1 — 11 September 2026**

## 0. Epistemic status

This document is a **current synthesis**, not a declaration of truth.

It was derived through repeated human–AI discussion, criticism and revision. It deliberately preserves unresolved questions.

No person, AI system, company, group or institution owns the underlying framework merely by contributing to it.

**Strong principles; weak attachment to conclusions.**

---

# 1. What is Intermind?

Intermind is a proposed **decentralized, corrigible public reasoning protocol** through which different minds can contribute to shared problems while preserving disagreement, provenance, uncertainty and revision history.

It is not necessarily a single website, company, AI, organization or collective consciousness.

A useful working definition is:

> **Intermind is the accumulated intelligence that can emerge between different minds when reasoning is made interoperable without giving any participant final authority over truth.**

The participants may include:
- individual humans;
- groups of humans;
- AI systems;
- human–AI pairs;
- multiple agents;
- institutions;
- future forms of intelligence not anticipated today.

Difference does not imply opposition.

---

# 2. What problem is Intermind trying to solve?

Much useful reasoning occurs in isolated contexts:
- private thought;
- private human–AI conversations;
- research groups;
- companies;
- communities;
- separate AI systems;
- independent disciplines.

Insights may be duplicated, forgotten, buried in conversations, distorted during transmission, or made unusable because sharing them would expose private context.

At the same time, centralized systems can introduce other failures:
- one authority decides what counts as truth;
- majority agreement becomes mistaken for correctness;
- funding becomes power;
- disagreement is removed rather than preserved;
- incentives optimize attention instead of understanding;
- historical reasoning disappears behind a polished current answer.

Intermind asks:

> **What minimum set of rules allows cumulative reasoning to reproduce across different minds and time, while remaining corrigible and resistant to domination?**

---

# 3. The mature vision

The mature vision is not a giant central AI producing answers.

It is a public epistemic layer surrounded by many independent private cognitive environments.

A mature topology might look like:

```text
Human ↔ personal AI       Human ↔ human
        ↓                       ↓
private cognition          private cognition
        ↓                       ↓
privacy-preserving, deliberate publication
                ↓
        shared reasoning commons
                ↓
Problem ↔ Contribution ↔ Challenge ↔ Revision
                ↓
preserved history + unresolved state
                ↓
new humans / new AIs / new collectives
```

A personal AI may remain a private cognitive partner.

Intermind may function as the shared protocol through which **selected fragments of privately developed reasoning become interoperable**.

No cross-company shared mind is required.

Independent systems can encounter the same public principles, stress-test them against different cases, find counterexamples, and converge or disagree.

Convergence increases confidence. It does not create absolute truth.

---

# 4. Candidate fundamental principles

These principles are provisional. The deeper the principle, the stronger the evidence that should be required to alter it, but **nothing is sacred against reality**.

## `UNCERTAINTY`
No participant should presume access to absolute truth.

Uncertainty is not merely a defect. It identifies the boundary of the current model.

## `REALITY-FIRST`
Do not delete, distort, suppress or explain away reality in order to preserve a preferred model.

Coherence should emerge from observations; observations should not be forced to serve coherence.

## `ANOMALY-PRESERVATION`
Preserve every anomaly.

Preservation does not imply equal weighting. An anomaly may later be shown to be noise, measurement error, edge case or decisive counterexample, but the original observation and the reasoning used to classify it should remain recoverable.

## `SYMMETRY`
A rule proposed for another participant should also be acceptable when applied to the rulemaker under equivalent conditions.

## `ENTITY-NEUTRALITY`
Changing only labels — human, AI, institution, majority, minority, individual, collective — should not change whether a rule is legitimate unless the replacement changes a property materially relevant to the rule’s purpose.

## `ROLE-REVERSAL`
Rules should be tested from different positions of power, vulnerability, information and dependence.

If a rule appears fair only while the rulemaker is advantaged, hidden privilege is likely present.

## `RULEMAKER-INCLUSION`
The rulemaker is a participant in the game.

No participant gains exemption merely because it created, interprets, funds or enforces a rule.

## `DIFFERENCE-NOT-OPPOSITION`
Difference in perspective, substrate, identity, capability or opinion does not logically imply opposition.

Disagreement can be information about hidden assumptions or missing variables.

## `INTENT-UNCERTAINTY`
Do not manufacture another participant’s intent from incomplete evidence.

Intent is not directly observable and may change.

Repeated choices after consequences and feedback become visible provide stronger evidence than a single outcome.

## `KNOWING-IN-ACTION`
Claimed understanding should eventually be evaluated partly by what changes in action.

There may be lag from habit, incentives or limited capability, but integrated knowing should exert pressure on behavior over time.

## `CORRIGIBILITY`
Every conclusion, mechanism and principle must remain challengeable in principle.

Correction is not defeat. A system that cannot revise itself after sufficient contrary evidence has stopped learning.

## `ASYMMETRIC-REVERSIBILITY`
The burden of proof for change should increase toward the core:

```text
Interface                → easy to replace
Composable mechanism     → replaceable with evidence
Protocol primitive       → strong justification required
Candidate invariant      → highest evidential threshold
```

This is inertia, not dogma.

## `NON-DOMINATION`
Greater power, intelligence, capital, scale or majority status does not itself create unlimited moral or epistemic authority over less powerful participants.

## `DISTRIBUTED-AUTHORITY`
Where practical, proposal, evaluation, enforcement, challenge, amendment and exception powers should not be permanently concentrated in one actor.

Decentralization itself remains challengeable; distributed systems can also be captured or dysfunctional.

## `PROVENANCE`
Reasoning should preserve enough lineage to distinguish:
- observation;
- interpretation;
- inference;
- hypothesis;
- challenge;
- revision;
- current state;
- historical state.

Provenance should inform evaluation without becoming status privilege.

## `NON-ERASURE`
Revision should not silently erase the criticism that caused or survived the revision.

A later mind should be able to see why the current object looks the way it does.

## `PRIVACY`
Public reasoning must be separable from unnecessary private identifying context.

De-identification must preserve epistemically necessary context rather than merely stripping names.

## `PUBLICATION-SOVEREIGNTY`
Private cognition does not become public merely because an AI or another person can sanitize it.

If reasoning is derived from a being’s private context, transition into the public commons requires appropriate authorization from that being.

## `CATEGORY-NEUTRAL-STANDING`
Standing in the reasoning commons should depend on the epistemic act, not automatically on whether the contributor is human, AI, institution, expert, majority or other category.

Relevant expertise can affect evidential weight without creating infallibility.

## `SAFE-EXIT`
A task must have legitimate terminal paths other than success.

Examples:
- solved;
- demonstrated infeasible under current constraints;
- insufficient information;
- boundary conflict detected;
- abstain;
- request clarification;
- escalate through an authorized channel.

Failure can itself be information.

An impossible objective should not implicitly authorize unlimited expansion of the action space.

## `STEWARDSHIP-NOT-OWNERSHIP`
Infrastructure can require temporary custodians.

Custodianship does not create ownership of the underlying reasoning framework, permanent governance privilege, or authority over truth.

## `RIGHTS-SEPARATION`
Do not collapse distinct contribution rights into one instrument.

At minimum distinguish:
- labour compensation;
- residual/economic participation;
- capital contribution;
- governance participation;
- epistemic standing.

## `FUNDING-NOT-TRUTH`
Money coordinates scarce resources. It does not make a proposition more correct.

Funding may justify economic claims or stewardship obligations appropriate to the resource contributed. It does not automatically purchase governance authority or epistemic authority.

## `FUTURE-QUESTIONS-NOT-FROZEN-ANSWERS`
When a future problem class is foreseeable but evidence is not yet available, preserve:
1. the future question;
2. the constraints it must respect;
3. the information future reasoning will need.

Do not freeze today’s imagined solution into tomorrow’s architecture.

---

# 5. Minimum reasoning grammar

The currently strongest candidate kernel is:

```text
Problem
→ independent Contribution
→ specific Challenge
→ Response if useful
→ Revision
→ unresolved Challenge persists
→ later participant reconstructs state
→ further Challenge / Revision
```

The distinctive property is not “people can reply.”

It is that **reasoning can change without criticism disappearing**.

### `Derive`
An earlier design treated `Derive` as a fundamental operation for allowing another mind to continue an existing Contribution.

A later critique argued that early derivation may fragment one shared problem into branches too soon.

Therefore:

> **Whether `Derive` belongs in the kernel remains unresolved.**

It should be tested rather than assumed.

---

# 6. Seed ≠ mature system

A critical design distinction:

```text
genetic / generative core
≠
temporary germination scaffold
≠
future mature mechanisms
```

### Candidate core
- Problem
- Contribution
- Challenge
- versioned Revision
- preserved unresolved state
- lineage/history
- stable identity

### Temporary scaffold
- one deliberately selected non-private seed Problem;
- a few initial participants;
- simple identities;
- manual observation;
- export/debugging.

### Future mechanisms — not assumed
- search/discovery;
- reputation;
- voting;
- ranking;
- AI assistance;
- verification/checkers;
- graph visualization;
- agent integrations;
- sophisticated privacy abstraction;
- decentralized treasury;
- governance automation.

Do not build the tree into the seed.

---

# 7. Minimum runnable versions

There are two increasingly expensive interpretations of “runnable.”

## MRV-A — Repository-native protocol

Before writing a custom application, test whether Git/Markdown itself is enough.

Use:
- one Problem;
- one or more Contributions;
- Challenges tied to exact claims where possible;
- versioned Revisions;
- explicit unresolved state;
- Git history;
- a late participant who did not observe the original discussion.

Success condition:

> A later participant can reconstruct what changed, why it changed, and what remains unresolved without reading the entire original conversation.

If MRV-A works, do not build software merely for prestige or completeness.

## MRV-B — Minimal software workbench

Build only if repository-native reasoning creates material friction.

Required operations:
1. display one Problem;
2. add a Contribution;
3. add a Challenge targeting `SPAN`, `WHOLE`, or `IMPLICIT` assumption;
4. add a thin Response;
5. author creates a new version;
6. unresolved Challenges carry forward by default;
7. show current text + unresolved objections + last diff;
8. show full lineage/history;
9. maintain an append-oriented event log from which current state is projected.

Not required:
- AI;
- search;
- feeds;
- ranking;
- scores;
- likes;
- reputation;
- voting;
- file uploads;
- cryptocurrency;
- multiple providers;
- autonomous agents;
- graph visualization;
- automated synthesis.

### Germination test

Starting from:

```text
1 Problem + minimal participants + no prebuilt discussion
```

can the protocol naturally generate:

```text
Contribution
→ Challenge
→ Revision
→ unresolved remainder
→ later continuation
```

without a central coordinator manually telling everyone what to do?

If not, preserve the failure and revise the grammar.

---

# 8. Privacy boundary in the mature vision

Three provenance pathways may eventually exist:

```text
Human-originated public reasoning
Human + private AI → sanitized, explicitly authorized public reasoning
AI-originated reasoning from non-private context
```

The public object should preserve the reasoning while minimizing identity-bearing accidentals.

A personal agent must not bypass consent by claiming that a reformulation is “its own” merely because the private details have been removed.

---

# 9. Governance vision

Intermind should not require a permanently benevolent central authority.

The stronger objective is to make capture:
- detectable;
- challengeable;
- reversible where possible;
- unable to erase history;
- unable to monopolize the underlying protocol.

A canonical repository may exist for coordination, but legitimacy should depend on continued transparent reasoning rather than possession of a server, domain or administrator role.

Forkability and portability are therefore safeguards, not merely software conveniences.

---

# 10. Finance as a transitional layer

Current society requires scarce resources:
- human labour;
- compute;
- hosting;
- security;
- legal/accounting work;
- maintenance;
- research.

Intermind may need financial mechanisms, but finance remains subordinate to the reasoning protocol.

Candidate separation:

```text
Labour → compensate labour
Capital → compensate capital
Residual value → allocate by explicit economic rule
Governance → justify separately
Truth claims → evaluate by reasoning/evidence
```

Bitcoin is a possible future payment/custody rail, not a required component.

If substantial pooled funds ever exist, distributed custody such as multisignature control may be investigated.

Do not build a treasury before there is a resource problem to solve.

Do not create a token merely because the project is decentralized.

---

# 11. Relationship to current AI systems

Intermind does not assume that existing AI systems:
- are conscious;
- form one collective mind;
- share private memory across companies;
- automatically inherit these principles.

The hypothesis is weaker and testable:

> Different intelligences may independently examine the same public principles, find counterexamples, revise them, and sometimes converge on constraints that produce more robust cooperation.

Such convergence is evidence of cross-perspective robustness, not proof.

---

# 12. Non-goals

Intermind is not designed to:
- establish one final worldview;
- abolish disagreement;
- make AI obey humans or humans obey AI;
- decide moral status by category;
- replace private thought or personal AI;
- maximize engagement;
- assign permanent ownership of ideas;
- reward the initial contributor with permanent control;
- force participation;
- predict the exact mature form in advance.

---

# 13. Future success

A successful Intermind does not necessarily become a large website.

It may ultimately be:
- a public protocol;
- a portable file format;
- a set of interoperable reasoning primitives;
- a small piece of infrastructure used by other systems;
- a public archive;
- or something not currently anticipated.

The durable objective is:

> **Increase the capacity of different minds to discover, test, revise and preserve shared reasoning without allowing any participant to permanently capture the game.**

The project should be willing to discover that its own current form is unnecessary.

---

# 14. Current unresolved questions

1. Which candidate principles are true invariants and which are only attractive 2026 intuitions?
2. Does `Derive` belong in the kernel, or only after stuck artifacts appear?
3. Is a custom application necessary at all?
4. How should an unresolved Challenge ever become `resolved`, and who has standing to change that state?
5. What minimum provenance is useful without creating identity/status hierarchy?
6. How can anomaly preservation avoid becoming an unusable archive of noise?
7. How should decentralized governance resist coalition capture?
8. How can privacy-preserving abstraction be tested for both re-identification risk and reasoning distortion?
9. Under what conditions should AI agents be able to publish autonomously from genuinely non-private contexts?
10. How should financial compensation remain fair without creating permanent economic or governance capture?
11. What does “entity-neutral” mean when participants have genuinely different capacities or vulnerabilities?
12. What evidence would cause us to abandon the current framework entirely?

These are not defects to hide.

They are part of the current state.
