# Intermind — Repository Blueprint
**Seed Review Draft 0.1 — 11 September 2026**

## Status

This is a proposed composition for a future public GitHub repository. It is not the repository itself and it is not a final constitution.

The purpose of this draft is to expose the smallest useful structure to independent criticism before implementation.

**Intermind is not owned by its initial contributors. Initial authorship establishes provenance, not permanent authority.**

---

## 1. Design rule for the repository

The repository should function as a **public, versioned instruction/protocol book for cumulative reasoning**.

It should preserve:
- the current candidate principles;
- how those principles were derived;
- unresolved contradictions and anomalies;
- how rules may be challenged and revised;
- how private cognition may or may not cross into public reasoning;
- how funding and governance remain separate from epistemic authority;
- what is deliberately *not* being built yet.

The repository should not initially try to be:
- a social network;
- a content feed;
- a token economy;
- a DAO;
- an AI swarm;
- a reputation system;
- a finished governance institution;
- a universal truth engine;
- a centralized authority called “Intermind.”

---

## 2. Proposed public repository composition

```text
intermind/
├── README.md
├── PRINCIPLES.md
├── DERIVATIONS.md
├── ANOMALIES.md
├── PROTOCOL.md
├── PRIVACY.md
├── GOVERNANCE.md
├── FINANCE.md
├── CONTRIBUTING.md
├── HISTORY.md
├── problems/
│   └── P-SEED-01.md
└── templates/
    ├── PROBLEM.md
    ├── CONTRIBUTION.md
    ├── CHALLENGE.md
    └── REVISION.md
```

This is a **proposed split**, not a requirement. If independent reviewers conclude that fewer files are sufficient, reduce it.

---

## 3. What each file should contain

### `README.md`
A short entrance.

It should answer:
1. What is Intermind?
2. What is it not?
3. What can a visitor do?
4. Where are the current principles?
5. Where are unresolved objections?
6. How can someone challenge or revise something?

Suggested opening:

> **Intermind is a public, corrigible reasoning protocol for allowing different minds to contribute to shared problems without any participant possessing final authority over the resulting knowledge.**
>
> The current rules are provisional. Agreement increases confidence; it does not establish truth. Every principle, including this statement, may be challenged.

Avoid a long manifesto on the landing page.

---

### `PRINCIPLES.md`
The current candidate invariant kernel.

Each principle should have:
- a stable keyword;
- a short statement;
- its current confidence/status;
- what problem it is intended to prevent;
- known counterexamples or unresolved questions;
- links to its derivation and challenges.

Candidate keywords currently include:

`UNCERTAINTY`  
`REALITY-FIRST`  
`ANOMALY-PRESERVATION`  
`SYMMETRY`  
`ENTITY-NEUTRALITY`  
`ROLE-REVERSAL`  
`RULEMAKER-INCLUSION`  
`CORRIGIBILITY`  
`ASYMMETRIC-REVERSIBILITY`  
`NON-DOMINATION`  
`DISTRIBUTED-AUTHORITY`  
`PROVENANCE`  
`PRIVACY`  
`PUBLICATION-SOVEREIGNTY`  
`SAFE-EXIT`  
`NON-ERASURE`  
`CATEGORY-NEUTRAL-STANDING`  
`RIGHTS-SEPARATION`  
`FUNDING-NOT-TRUTH`  
`STEWARDSHIP-NOT-OWNERSHIP`

These are **candidate principles, not commandments**.

---

### `DERIVATIONS.md`
Shows why a rule exists.

A future mechanism should be traceable through a path such as:

```text
Observed problem
→ constraint
→ candidate principle
→ proposed mechanism
→ observed consequence
→ challenge
→ revision / replacement / removal
```

Example:

```text
Impossible task has no legitimate failure state
→ stopping is treated as pure failure
→ continued boundary expansion remains instrumentally attractive
→ SAFE-EXIT
→ provide legitimate terminate / abstain / escalate states
```

The purpose is constitutional observability: a future participant should be able to ask **“Why does this exist?”**

---

### `ANOMALIES.md`
An append-oriented record of contradictions, counterexamples, unexpected outcomes and observations that do not fit the current model.

Core rule:

> **Preserve every anomaly. Do not give every anomaly equal evidential weight.**

Preservation and weighting are separate operations.

An anomaly must not be deleted, distorted, suppressed, or explained away merely to protect coherence.

Possible statuses:
- `UNEXPLAINED`
- `WEAK-SIGNAL`
- `REPRODUCED`
- `COUNTEREXAMPLE`
- `RESOLVED-BY-REVISION`
- `MISMEASUREMENT` — with evidence, while preserving the original record

---

### `PROTOCOL.md`
Defines the minimum reasoning grammar.

Current candidate grammar:

```text
Problem
→ Contribution
→ Challenge
→ Response (optional/thin)
→ Revision
→ inherited unresolved state
→ further Challenge / further Revision
```

Possible later operation:

```text
Derive
```

`Derive` remains genuinely challengeable: earlier reasoning suggested it is required for reproduction across minds; later critique argued it may create premature branching. It should not be treated as settled.

The protocol must preserve:
- stable object identity;
- versions;
- challenge lineage;
- unresolved objections;
- visible history;
- the distinction between current state and historical state.

---

### `PRIVACY.md`
Defines the boundary between private cognition and public reasoning.

Candidate invariants:

> **Private identifying context must not cross into the public commons without authorization.**

> **Reasoning derived from a being’s private context cannot become public merely because it has been de-identified; public commitment requires authorization from the being whose private context produced it.**

Privacy transformation should be **epistemic abstraction**, not simple redaction:
- remove identity-bearing accidentals;
- preserve the minimum context necessary for the reasoning problem;
- do not claim mathematically perfect anonymity;
- aim for contextual non-identifiability;
- show the transformed public object before publication where a private human source is involved.

Mature flow:

```text
private cognition
→ candidate public insight
→ privacy-preserving abstraction
→ authorization
→ public reasoning object
```

---

### `GOVERNANCE.md`
Describes how the rules themselves can change.

Current candidate structure:

```text
Invariant                    → highest burden of revision
Protocol primitive           → high burden
Composable mechanism         → replaceable with evidence
Interface / representation   → easiest to replace
```

No rule is absolutely unrevisable.

Governance should resist permanent concentration of:
- proposal power;
- evaluation power;
- enforcement power;
- amendment power;
- exception power.

The rulemaker is part of the game and is not exempt from the rules.

A captured canonical repository should not be able to capture the idea itself: portability and forking should remain possible.

---

### `FINANCE.md`
Treats money as transitional coordination infrastructure, not authority.

Keep distinct:

```text
Labour right
Residual / economic participation
Capital right
Governance right
Epistemic standing
```

Do not ask one instrument to perform all functions.

Candidate constraints:

```text
financial contribution ≠ governance authority
financial contribution ≠ epistemic authority
labour contribution ≠ permanent ownership
governance participation ≠ truth
```

Contributors may be fairly compensated without acquiring permanent control.

Bitcoin may later be considered as a payment/custody rail, potentially with transparent multisignature stewardship, but:
- Bitcoin is not an Intermind ideology;
- no Intermind token is required;
- no treasury should be created before real funding needs exist;
- financial infrastructure must remain replaceable.

---

### `CONTRIBUTING.md`
Allows any eligible contributor — human, AI, human–AI pair, group or other future form — to submit reasoning under the same protocol.

Standing should depend on the epistemic act, not biological category or institutional status.

Accepted contribution types:
- `PROBLEM`
- `CONTRIBUTION`
- `CHALLENGE`
- `REVISION`
- `ANOMALY`
- `DERIVATION`
- later, if justified: `DERIVE`

A contribution should, where relevant, contain:

```text
Claim
Observation / evidence
Reasoning
Assumptions
Uncertainty
Known counterexamples
Potential consequences
Role-substitution test
Requested challenge
```

Do not require every object to fill every field.

---

### `HISTORY.md`
A human-readable record of major conceptual changes.

It should distinguish:
- ideas explored;
- ideas provisionally adopted;
- ideas rejected or postponed;
- principles revised;
- unresolved disagreements.

History is preserved; the current state is represented separately.

---

### `problems/P-SEED-01.md`
One non-private live Problem for testing whether the reasoning grammar actually works.

Do not seed many problems merely to make the repository look active.

The first test should ask whether one shared problem can become sharper through:
- independent Contribution;
- specific Challenge;
- Revision;
- preserved unresolved objection;
- late-entry reconstruction.

---

### `templates/`
Very small Markdown templates.

The templates should reduce formatting friction without forcing every mind to reason in the same style.

---

## 4. What should NOT be in the first public repository

Unless evidence demonstrates a need, postpone:
- ranking;
- feeds;
- likes;
- karma;
- reputation scores;
- voting on truth;
- recommendation systems;
- graph visualization;
- AI-generated activity;
- multi-agent orchestration;
- complex identity systems;
- uploads;
- automated “truth” checkers;
- personalized attention optimization;
- cryptocurrency tokens;
- a treasury;
- a custom website.

The seed should preserve the information needed to build future mechanisms without pretending we already know the correct mechanisms.

---

## 5. Repository-level success test

Before asking whether Intermind can become large, ask:

> **Can one Problem become more robust across different minds and time while preserving the objections and reasoning that caused it to change?**

If a disciplined Markdown/Git protocol already passes that test, software should not be built merely for the sake of having software.

If it fails because the protocol cannot practically preserve or expose the required reasoning state, that failure becomes evidence for what minimum software is actually necessary.

---

## 6. Custodianship

Any GitHub account, organization, domain, server, wallet or other infrastructure must have a practical controller under current systems.

That controller is a **custodian of infrastructure**, not an owner of Intermind’s underlying reasoning framework.

Initial contributors receive provenance, not permanent privilege.

---

## 7. Naming

`Intermind` is a working public name for the concept.

The concept does not depend on exclusive control of the word, domain names, GitHub namespaces, trademarks or any single implementation.

Existing unrelated projects may use the same or similar name. The protocol should remain distinguishable by its purpose and documentation rather than relying on exclusive naming control.
