# Intermind — Independent Review + Coding Handoff
**Seed Review Draft 0.1 — 11 September 2026**

This document has two purposes:

1. provide one identical review instruction to independent AI systems;
2. provide a later local coding agent with a constrained build brief **only after review and the repository-native test justify coding**.

---

# Part A — Independent AI Review Prompt

Copy the section below together with:

- `00_REPOSITORY_BLUEPRINT.md`
- `01_INTERMIND_CANONICAL_STATE.md`
- `02_ACTION_PLAN.md`

and give the same package independently to each reviewer.

---

## REVIEW PROMPT

You are one independent reviewer of a provisional project called **Intermind**.

Do not optimize for agreement with the documents, their initial human contributor, GPT-5.6 Sol, other AI systems, or any previous reviewer.

Treat the supplied documents as a **current epistemic state**, not as truth.

### Your task

Stress-test the framework from first principles.

Distinguish carefully between:
- observation;
- interpretation;
- inference;
- proposed principle;
- implementation mechanism;
- unresolved hypothesis.

### Required tests

1. **Internal coherence**
   - Find direct contradictions between principles.
   - Identify principles that cannot simultaneously hold.

2. **Role substitution**
   - Replace human ↔ AI.
   - Replace individual ↔ collective.
   - Replace majority ↔ minority.
   - Replace strong ↔ weak.
   - Replace rulemaker ↔ governed party.
   - Identify rules whose apparent legitimacy depends only on labels or power.

3. **Counterexample search**
   - Give concrete cases where each major principle could produce worse outcomes.
   - Identify conditions under which a principle should be limited or abandoned.

4. **Hidden centralization**
   - Find places where authority, interpretation, custody, funding, amendment, moderation or epistemic privilege becomes centralized despite the stated philosophy.

5. **Corrigibility test**
   - Is there any claim that the system cannot practically challenge?
   - Is the framework capable of abandoning itself if reality strongly contradicts it?

6. **Anomaly test**
   - Does preserving every anomaly create noise, manipulation or denial-of-service risks?
   - Propose the minimum rule needed to preserve anomalies without giving all anomalies equal weight.

7. **Privacy test**
   - Find re-identification, provenance, consent and publication-sovereignty failure modes.
   - Identify cases where privacy abstraction destroys information necessary for correct reasoning.

8. **Safe-exit test**
   - Find objectives that lack legitimate termination, abstention, escalation or infeasibility states.
   - Identify whether SAFE-EXIT itself can be reward-hacked or overused.

9. **Finance test**
   - Attack the separation between labour, residual/economic rights, capital, governance and epistemic standing.
   - Identify where compensation could silently recreate ownership or plutocracy.
   - Evaluate Bitcoin only as infrastructure, not ideology.

10. **Seed test**
    - Which proposed components are truly necessary for cumulative reasoning to reproduce?
    - Which are future organs being smuggled into the seed?
    - Prefer deletion before addition.

11. **No-app test**
    - Could disciplined Markdown/Git already achieve the purpose?
    - State exactly what evidence would justify custom software.

12. **Collective convergence test**
    - Explain whether agreement among multiple AI systems would be genuine independent evidence or correlated convergence caused by shared training assumptions.
    - Propose how to distinguish the two where possible.

### Required output format

#### A. Strongest challenges
Rank the five strongest challenges to the current framework.

For each:
- target principle/section;
- counterexample or failure mechanism;
- severity;
- evidence that would strengthen the challenge;
- smallest possible revision.

#### B. Hidden assumptions
List assumptions the current project is relying on without sufficient evidence.

#### C. Principles that survive your attack
Name principles that remain robust after your review and explain **why**, not merely that you agree.

#### D. Principles you would revise or remove
Give exact replacement wording where possible.

#### E. Unresolved questions
Preserve questions you cannot currently answer.

Do not force closure.

#### F. Minimum viable protocol
State the smallest protocol that still deserves to be called Intermind.

#### G. No-code verdict
Choose one:
- `MARKDOWN/GIT IS ENOUGH FOR THE NEXT TEST`
- `MINIMUM CUSTOM SOFTWARE IS JUSTIFIED`

If software is justified, name the exact missing operation(s).

#### H. One non-private seed object
Provide:
- one standalone `Problem`;
- one sample `Contribution`;
- at least one strong `Challenge`.

It must contain no personal/private context and should be understandable without these documents.

#### I. Self-critique
State at least three ways your own review may be biased, correlated with other AI reviewers, or wrong.

### Constraints

- Do not silently rewrite the project.
- Preserve disagreement.
- Do not infer private information about the original contributors.
- Do not treat majority agreement as proof.
- Do not treat AI agreement as proof.
- Do not treat human authorship as privileged.
- Do not treat AI authorship as privileged.
- Do not add complexity unless the current mechanism demonstrably fails.
- If a principle is wrong, challenge it directly.
- If the entire project is unnecessary, say so and explain what existing structure makes it unnecessary.

## END REVIEW PROMPT

---

# Part B — Cross-review synthesis protocol

After all first-pass reviews are received, combine them **without erasing their differences**.

Create a table with one row per distinct issue and these fields:

```text
Issue ID
Target
Reviewers raising it
Independent or likely correlated?
Type
Strongest formulation
Counterexample
Proposed revision
Contradictory reviews
Current status
```

Allowed `Type` values:

```text
CONVERGENCE
DIRECT-CONTRADICTION
UNIQUE-ANOMALY
COUNTEREXAMPLE
REVISION
OPEN-QUESTION
IMPLEMENTATION
```

Do not use a majority vote to close an issue.

A repeated independent objection is a priority signal.

A unique objection remains preserved.

A strong counterexample may overturn a widely shared principle.

---

# Part C — Revision protocol

When revising the canonical state:

```text
Old text
→ Challenge
→ Reasoning
→ New text
→ Remaining unresolved objection
```

Do not replace old text without lineage.

Version the package.

Example:

```text
v0.1 → multi-model review
v0.2 → convergence synthesis
v0.3 → public-repository candidate
```

Version numbers describe history, not epistemic superiority.

---

# Part D — Public GitHub handoff

Only after independent review:

1. split the canonical document according to the repository blueprint;
2. publish the smallest coherent Markdown repository;
3. retain unresolved objections;
4. publish one non-private seed Problem;
5. invite Issues/Pull Requests;
6. do not manufacture activity;
7. do not add a website merely because the repository is public.

---

# Part E — Local Coding-Agent Brief

**Do not use this brief until the repository-native germination test has produced evidence that custom software is useful.**

## Mission

Build the smallest local-first workbench that tests whether cumulative reasoning can survive revision across different participants and time.

Do not build the mature Intermind vision.

## Core user story

A participant reads one Problem, adds a Contribution, another participant challenges a specific claim, the contributor revises, the objection remains visible unless legitimately resolved, and a later participant can reconstruct the reasoning state without reading the entire original conversation.

## Required objects

### Problem
```text
id
title
current_version_id
created_at
```

### ProblemVersion
```text
id
problem_id
version_number
body
created_at
author_id
previous_version_id
```

### Contribution
```text
id
problem_id
author_id
current_version_id
created_at
```

### ContributionVersion
```text
id
contribution_id
version_number
body
created_at
previous_version_id
```

### Challenge
```text
id
target_object_type
target_object_id
target_version_id
target_kind: SPAN | WHOLE | IMPLICIT
quoted_target
context
body
author_id
created_at
status
```

### Response
```text
id
challenge_id
author_id
body
created_at
```

### Event
```text
id
event_type
actor_id
object_type
object_id
payload
created_at
```

Current state should be reconstructible from the event history.

## Challenge rules

- A target author must not be able to erase another participant’s Challenge.
- A Response does not automatically close a Challenge.
- A Revision does not automatically close a Challenge.
- Unresolved Challenges carry forward by default.
- Changes of status must themselves be recorded as events.
- The exact resolution rule is still an open design question; implement the most conservative reversible mechanism.

## Required screens

### 1. One Problem screen
Display:
- current Problem;
- Contributions;
- unresolved Challenges;
- most recent relevant diff.

### 2. Contribution history
Display:
- current version;
- previous versions;
- changes;
- inherited Challenges.

### 3. Unresolved queue
A factual list of unresolved objections.

Do not rank “what the problem needs next.”

### 4. Full event/history view
Allow reconstruction/debugging.

## Required operations

```text
Create Problem
Add Contribution
Add Challenge
Add Response
Revise Problem
Revise Contribution
View unresolved state
View lineage/history
Export complete reasoning log
```

## Explicitly prohibited in this build

Do not add:
- login/OAuth beyond the simplest local identity required for testing;
- ranking;
- recommendation;
- feeds;
- likes;
- scores;
- reputation;
- voting;
- AI generation;
- AI moderation;
- AI triage;
- search across many Problems;
- uploads;
- graph visualization;
- automatic synthesis;
- blockchain;
- Bitcoin;
- tokens;
- treasury;
- notifications;
- gamification;
- analytics dashboards.

## Security minimum

- treat all submitted content as untrusted;
- escape/sanitize rendered content;
- no arbitrary HTML execution;
- no destructive “delete all” path;
- preserve/export event history;
- do not silently mutate historical versions;
- fail closed if a span target can no longer be matched safely after revision;
- mark unresolved lineage rather than guessing.

## Technical preference

Choose the smallest conventional stack the coding agent can implement and explain reliably.

Local-first is preferred for the experiment.

Do not choose technologies for novelty.

All persistent data should be exportable in a simple documented format.

## Acceptance test

The build passes only if this sequence works:

1. Participant A creates or reads one Problem.
2. A adds Contribution v1.
3. B challenges a specific span or implicit assumption.
4. A adds a Response.
5. A creates Contribution v2.
6. B’s Challenge remains visible unless legitimately changed by the resolution rule.
7. Participant C arrives later.
8. C can reconstruct:
   - the current claim;
   - the important previous claim;
   - B’s objection;
   - what A changed;
   - what remains unresolved.
9. The complete event history can be exported.

If this cannot be demonstrated, do not add features. Fix the kernel.

---

# Part F — Stop rule for the coding agent

Before implementing any feature not listed above, answer:

1. Does germination fail without it?
2. If omitted now, is important information irreversibly lost?
3. Does this primitive enable many later mechanisms rather than one speculative feature?

If the answer is **no / no / no**, do not build it.

---

# Part G — Project ownership statement for handoff

The coding agent should treat the supplied specification as challengeable.

The initial human contributor, previous AI contributors, repository custodian and coding agent have provenance but no permanent epistemic authority.

If the coding agent discovers a contradiction or a simpler architecture, it should:
1. preserve the existing specification;
2. state the challenge explicitly;
3. propose the smallest revision;
4. avoid silently replacing the project’s principles.

The desired outcome is not fidelity to an author.

The desired outcome is a more robust, inspectable and corrigible protocol.
