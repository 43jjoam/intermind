# Intermind Seed Review Package v0.1

Files:
1. `00_REPOSITORY_BLUEPRINT.md` — proposed future public repository composition.
2. `01_INTERMIND_CANONICAL_STATE.md` — current project purpose, principles, mature vision and minimum runnable versions.
3. `02_ACTION_PLAN.md` — actor-neutral ordered actions with stop conditions.
4. `03_REVIEW_AND_CODING_HANDOFF.md` — identical multi-AI review prompt, synthesis method, and constrained local coding-agent brief.

This package is intentionally provisional and designed to be challenged before public implementation.
